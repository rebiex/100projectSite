<?php /*Template Name: Who we are*/ ?>
<?php get_header() ?>

<?php get_template_part('template-parts/header-alone') ?>

<div class="large-12 columns section align-center contact-page">
	<img src="<?= get_template_directory_uri() . '/images/circle.png' ?>" alt="" />
	<h4 class="align-center">Hey! We are Project 100</h4>
	<span class="align-center small-bold">NICE TO MEET YOU. THIS IS OUR MANIFESTO.</span>

	<div class="large-6 medium-10 small-10 align-left margin-center">
		<p class="contact-text">down and I'd like to take a minute, just sit right there, I'll tell you how I <br>down and I'd like to take a minute, just sit right there, I'll tell you how I <br>became the prince of a town called Bel-Air.<br><br><br>In west Philadelphia born and raised, on the playground was where I<br>spent most of my days. Chillin' out maxin' relaxin' all cool and all shoo<br>ting some b-ball outside of the school. When a couple of guys who<br>were up to no good started making trouble in my neighborhood...</p>
	</div>
	<div class="clearfix"></div>

	<div class="large-5 medium-5 small-10 align-center margin-center">
		<hr class="medium-line" />
		<p class="mulibolditalic">
			I got in one little fight and my mom<br>
			got scared. She said: “you’re moving with<br>
			your auntie and uncle in Bel Air!”
		</p>
		<hr class="medium-line" />
	</div>

	<div class="clearfix"></div>

	<div class="large-6 medium-10 small-10 align-left margin-center">
		<p class="contact-text">
			down and I'd like to take a minute. Just sit right there I'll tell you how I<br>became the prince of a town called Bel-Air.<br><br><br>In west Philadelphia born and raised, on the playground was where I <br>spent most of my days. Chillin' out maxin' relaxin' all cool and all shoo<br>ting some b-ball outside of the school. When a couple of guys who <br>were up to no good started making trouble in my neighborhood...
		</p>
	</div>

</div>
<div class="clearfix"></div>

<?php get_template_part('template-parts/footer-page') ?>


<?php get_footer() ?>
