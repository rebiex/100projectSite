<?php get_header() ?>

	<div class="large-12 columns section">
		<div class="header">
			<div class="large-12 columns">
				<div class="large-6 medium-6 small-6 columns">
					<span class="title">Project <span class="strong">100</span></span>
				</div>
				<div class="large-6 medium-6 small-6 columns align-right">
					<a href="#" class="nav toggleMenu">
						<i class="fa fa-bars"></i>
					</a>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>

		<div class="content large-5 columns align-center">
			<img class="logo" src="<?= get_template_directory_uri() . '/images/logo.png' ?>" />
			<hr/>
			<p class="slogan">“Business is not about money.<br>It’s about making dreams come true<br>for others, and for yourself.</p>
			<hr/>
			<div class="clearfix"></div>
			<p class="bottom-slogan"><span>DEREK SIVERS,</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="right-text">ANYTHING YOU WANT</span></p>
		</div>

		<img src="<?= get_template_directory_uri() . '/images/s1.png' ?>" />
	</div>
	<div class="clearfix"></div>

	<div class="large-12 columns section">
		<div class="content-top large-5 columns align-center">
			<h1 class="site-title">Project <span class="ralewaybold">100</span></h1>
			<p class="text-content-top">
				Designed to help you tackle marketing<br>and design projects with 100% authenticity -<br>100% of the time.
			</p>
		</div>
		<img src="<?= get_template_directory_uri() . '/images/s2.png' ?>" />
	</div>
	<div class="clearfix"></div>

	<div class="large-12 columns section">
		<div class="content-left large-12 columns align-left">
			<h2 class="mulibold">We are innovative.</h2>
			<h2 class="mulibold">We are dreamers.</h2>
			<h2 class="mulibold">We are just as you are.</h2>

			<p>
				Consider us as your one stop solution for improving<br>your business. Armed with a wide set of marketing<br>experience and design skills, we work with start-ups<br>and small businesses.
			</p>

			<p>
				You’ll find that we can tackle any projects from start<br>
				to finish — all in house. Plus, you can rest easy<br>
				knowing that you’re getting high quality work.
			</p>

			<div class="large-12 columns align-center">
				<a href="#" class="btnmanifesto">
					Read our manifesto!
				</a>
			</div>
		</div>
		<img src="<?= get_template_directory_uri() . '/images/s3.png' ?>" />
	</div>
	<div class="clearfix"></div>

	<div class="large-12 columns section wedo align-center">
		<h3>We do marketing. We do design. We do strategy.</h3>

		<div class="large-5 medium-6 small-10 columns align-left square">
			<p>
				Marketing<br>
				Branding<br>
				Social Media<br>
				Lead Generation<br>
			</p>
		</div>

	</div>
	<div class="clearfix"></div>

	<div class="large-12 columns section clients align-center">
		<h3>Meet some of our clients!</h3>
		<p class="mulilight">COOL PEOPLE WHO’VE TRUSTED OUR WORK</p>

		<div class="large-12 columns logos">
			<div class="large-3 columns">
				<img src="<?= get_template_directory_uri() .'/images/deepdyve.png' ?>" />
			</div>
			<div class="large-3 columns">
				<img src="<?= get_template_directory_uri() .'/images/adidas.png' ?>" />
			</div>
			<div class="large-3 columns">
				<img src="<?= get_template_directory_uri() .'/images/sb.png' ?>" />
			</div>
			<div class="large-3 columns">
				<img src="<?= get_template_directory_uri() .'/images/amazon.png' ?>" />
			</div>
			<div class="clearfix"></div>
		</div>

		<div class="large-12 columns logos">
			<div class="row">
				<div class="large-4 columns">
					<img src="<?= get_template_directory_uri() .'/images/apple.png' ?>" />
				</div>
				<div class="large-4 columns">
					<img src="<?= get_template_directory_uri() .'/images/deepdyve.png' ?>" />
				</div>
				<div class="large-4 columns"></div>
				<div class="clearfix"></div>
			</div>
		</div>
		<div class="clearfix"></div>

	</div>
	<div class="clearfix"></div>

	<div class="large-12 columns section contact align-center contact">
		<h2>We wanna hear from you!</h2>
		<p>No strings. No sales BS. Let’s have a chat!<br>Tell me know what you’d like to do better. We’ll lay out the options and give you<br>advice where to start.And if we really CAN’T help, we’ll tell you that too.</p>
		<br>
		<br>
		<p>It’s ok, no spam. We promise.</p>
		<br>
		<br>
		<!-- Change the width and height values to suit you best -->
	<div class="typeform-widget" data-url="https://project100sample.typeform.com/to/lcoiIz" data-text="Contact Form" style="width:100%;height:100vh;"></div>
	<script>(function(){var qs,js,q,s,d=document,gi=d.getElementById,ce=d.createElement,gt=d.getElementsByTagName,id='typef_orm',b='https://s3-eu-west-1.amazonaws.com/share.typeform.com/';if(!gi.call(d,id)){js=ce.call(d,'script');js.id=id;js.src=b+'widget.js';q=gt.call(d,'script')[0];q.parentNode.insertBefore(js,q)}})()</script>
	</div>
	<div class="clearfix"></div>

	<div class="large-12 columns section align-center" style="height:500px !important;">

		<video src="<?= get_template_directory_uri() ?>/video/video.mp4"
			style="width:100%;border:0;height:100%;"
			autoplay="autoPlay"
		></video>

	</div>
	<div class="clearfix"></div>

	<div class="large-12 columns footer">
		<div class="row">
			<div class="large-3 medium-3 small-12 columns align-center">
				<img src="<?= get_template_directory_uri() . '/images/my.png' ?>" alt="My H. Nguyen" />
			</div>
			<div class="large-9 medium-9 small-12 columns align-left">
				<h3 class="bold">My H. Nguyen</h3>
				<h3 class="title">Entrepreneur, Author</h3>
				<p>
					Duis aute irure dolor in reprehenderit in voluptate velit esse<br>
					cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat<br>
					mollit anim id est laborum.
				</p>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>

<?php get_footer() ?>
