<div class="large-12 columns">
	<div class="no-image-header">
		<div class="large-12 columns">
			<div class="large-6 medium-6 small-6 columns">
				<span class="title">Project <span class="strong">100</span></span>
			</div>
			<div class="large-6 medium-6 small-6 columns align-right">
				<a href="#" class="nav toggleMenu">
					<i class="fa fa-bars"></i>
				</a>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<div class="clearfix"></div>
