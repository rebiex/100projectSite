<div class="large-12 columns footer-page align-center">

	<h3>Feeling the love?</h3>
	<span>NO STRINGS. NO SALES BS. HAVE A CHAT WITH US!</span>

	<br>
	<br>
	<br>
	<p>
		<img src="<?= get_template_directory_uri() . '/images/lets-chat.png' ?>" alt="Let's chat" />
	</p>

	<div class="social-buttons">
		<a href="#">
			<i class="fa fa-facebook"></i>
		</a>
		<a href="#">
			<i class="fa fa-twitter"></i>
		</a>
	</div>

	<small>PROJECT 100 – <?= date('Y') ?>  |  ALL RIGHTS RESERVED</small>
</div>
