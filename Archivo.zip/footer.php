<?php wp_footer(); ?>

</div>

</body>
</html>
