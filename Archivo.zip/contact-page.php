<?php /* Template Name: Contact Page */ ?>
<?php get_header() ?>

<?php get_template_part('template-parts/header-alone') ?>

<div class="large-12 columns section align-center contact-page">
	<img src="<?= get_template_directory_uri() . '/images/circle.png' ?>" alt="" />
	<h4 class="align-center">We would love to hear from you!</h4>
	<span class="align-center small-bold">NO SPAM, WE PROMISE</span>

	<div class="large-6 medium-10 small-10 align-left margin-center">
		<p class="contact-text">Good work starts with a good conversation. We’d like to hear from you.<br>If you need our help with your next project, drop an email.<br><br><br>No strings, no sales BS. Let’s have a chat. Tell me what you’d like to do<br>better. I’ll lay out the options and give you advice where to start. And if I<br>really CAN’T help, I’ll tell you that too.<br></p>
	</div>

	<div class="typeform-widget" data-url="https://project100sample.typeform.com/to/lcoiIz" data-text="Contact Form" style="width:100%;height:100vh;"></div>
	<script>(function(){var qs,js,q,s,d=document,gi=d.getElementById,ce=d.createElement,gt=d.getElementsByTagName,id='typef_orm',b='https://s3-eu-west-1.amazonaws.com/share.typeform.com/';if(!gi.call(d,id)){js=ce.call(d,'script');js.id=id;js.src=b+'widget.js';q=gt.call(d,'script')[0];q.parentNode.insertBefore(js,q)}})()</script>
</div>
<div class="clearfix"></div>

<?php get_template_part('template-parts/footer-page') ?>

<?php get_footer() ?>
