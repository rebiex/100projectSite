<?php
/*
Title: Post Details
Post Type: post
*/

piklist('field', array(
    'type' => 'text'
    ,'label' => __('Reading time')
    ,'columns' => 12
    ,'field' => 'time'
));
